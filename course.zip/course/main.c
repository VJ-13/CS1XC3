/**
 * @file main.c
 * @author Virendra Jethra
 * @brief This file uses the courses and student libraries
 * @date 2022-04-08
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Creates a course with random students enrolled in it and prints student informations through the use of course and student libraries
 * 
 * @return int returns exit status
 */
int main()
{
  //Initializes the random number generator
  srand((unsigned) time(NULL));

  //Creates course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  
  //Enrolls randomly generated students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Prints the top student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Prints all the students who are passing the course 
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}