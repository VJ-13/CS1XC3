/**
 * @file course.h
 * @author Virendra Jethra
 * @date 2022-04-08
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Course type stores the name, code, students and total number of students in the class 
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Enrolls the student into the course
 * 
 * @param course a pointer to the type course
 * @param student a pointer to the type student
 * @return Nothing
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Prints the course name, code and total students in the course
 * 
 * @param course a pointer to the type course
 * @return Nothing
 */
void print_course(Course *course);

/**
 * @brief Returns the pointer of the top student in the course
 * 
 * @param course a pointer to the type course
 * @return Student* 
 */
Student *top_student(Course* course);

/**
 * @brief Returns the pointer of the students passing
 * 
 * @param course a pointer to the type course
 * @param total_passing a pointer to the amount of people passing
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);