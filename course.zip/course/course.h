/**
 * @file course.h
 * @author Virendra Jethra
 * @brief This file contains the function declaration of the Course type.
 * @date 2022-04-08
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Course type stores the name, code, students and total number of students in the class 
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Enrolls the student into the course
 * 
 * @param course a pointer to the type course
 * @param student a pointer to the type student
 * @return Nothing
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Prints the course name, code and total students in the course
 * 
 * @param course a pointer to the type course
 * @return Nothing
 */
void print_course(Course *course);

/**
 * @brief Calculates the student with the highest average in the course
 * 
 * @param course a pointer to the type course
 * @return (Student*) returns the pointer of the student with the highest average in the course
 */
Student *top_student(Course* course);

/**
 * @brief Finds the students with average of more than or equal to 50
 * 
 * @param course a pointer to the type course
 * @param total_passing a pointer to the amount of students passing
 * @return (Student*) returns the pointer of the students with average of more than or equal to 50
 */
Student *passing(Course* course, int *total_passing);