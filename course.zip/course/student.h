/**
 * @file student.h
 * @author Virendra Jethra
 * @brief This file contains the function declaration of the Student type.
 * @date 2022-04-08
 */

/**
 * @brief Student type stores the first name, last name, the id of the student, grades and number of grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Adds the grades of the student
 * 
 * @param student a pointer to the type student
 * @param grade the grades of the student represented as an array
 * @return Nothing 
 */
void add_grade(Student *student, double grade);

/**
 * @brief Calculates the average of the student
 * 
 * @param student a pointer to the type student
 * @return (double) returns the average of the student
 */
double average(Student *student);

/**
 * @brief Prints out the students name, id, grades and the average
 * 
 * @param student a pointer to the type student
 * @return Nothing
 */
void print_student(Student *student);

/**
 * @brief Generates a new student random from a predetermine list of first and last name and rand function
 * 
 * @param grades number of grades for the student
 * @return (Student*) returns a points of student with assigned information 
 */
Student* generate_random_student(int grades); 
